# jShapes

This package includes some basic shape buildin blocks and some functions for working with them. 
